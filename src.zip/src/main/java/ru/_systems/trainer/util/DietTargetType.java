package ru._systems.trainer.util;

public enum DietTargetType {
    WEIGHT_LOSS, MAINTENANCE, MASS_GAIN

}
