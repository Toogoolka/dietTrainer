package ru._systems.trainer.util.exceptions;

public class InvalidListIdsException extends RuntimeException {
    public InvalidListIdsException(String message) {
        super(message);
    }
}
