package ru._systems.trainer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainerApplicationTests {

	@Test
	void contextLoads() {
	}

}
